package br.com.davidbuzatto.backendexemplospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendExemploSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendExemploSpringApplication.class, args);
	}

}
