package exemplorelatorioswing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploDeAplicacaoSpringComRelatorioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploDeAplicacaoSpringComRelatorioApplication.class, args);
	}

}
