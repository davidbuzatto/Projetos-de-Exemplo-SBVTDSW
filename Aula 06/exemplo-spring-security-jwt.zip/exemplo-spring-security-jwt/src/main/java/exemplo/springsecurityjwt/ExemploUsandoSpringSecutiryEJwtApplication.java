package exemplo.springsecurityjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploUsandoSpringSecutiryEJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploUsandoSpringSecutiryEJwtApplication.class, args);
	}

}
